import React from "react";
import ItemListContainer from "../components/ItemListContainer";

export default function Productos() {
  return <ItemListContainer />;
}
