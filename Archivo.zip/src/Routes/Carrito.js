import React from 'react';
import Cart from '../components/Cart';

export default function Carrito() {
  return (
    <Cart/>
  )
}
