import React from "react";
import ItemList from "./ItemList";

function ItemListContainer() {

    return (
        <div className="mt-5">
            <ItemList></ItemList>
        </div>
    );
}

export default ItemListContainer;